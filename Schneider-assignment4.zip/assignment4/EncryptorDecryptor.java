import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

/**
 *
 * @author mahmed27
 * 
 * Submission by Corey Schneider
 * ITIS 3200 - November 14, 2019
 */

class EncryptorDecryptor {


	/**
	 * This the the entry point of the program
	 */
	public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, 
	InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		// Message to encrypt
		// In your program this the message, a chat client wants to send to other clients
		String textToEncrypt = "Hello, how are you?";
		System.out.println("Original message: " + textToEncrypt);

		// This the secret key which is 128 bit long.
		// In your program, you have to load this key from a file
		String key = "I am secret key.";
		//String key = "";
		try {
			key = Files.lines(Paths.get("./symmetricKey.txt")).findFirst().get();
			//System.out.println(Files.lines(Paths.get("./symmetricKey.txt")).findFirst().get());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Symmetric key Length: " + (key.getBytes().length * 8) + " bit. Key: "+key);

		// Generate a KeySS
		Key secretkey = generateSymmetricKey(key, "AES");

		// Encryt text using generated key
		byte[] encryptedText = encryptOrDecryptText(secretkey, Cipher.ENCRYPT_MODE, textToEncrypt.getBytes());
		System.out.println("CipherText/Encrypted message: " + new String(encryptedText));

		// Decrypt Cipher text using same key
		byte[] decryptedText = encryptOrDecryptText(secretkey, Cipher.DECRYPT_MODE, encryptedText);

		// Print the decrypted text
		System.out.println("Decrypted message: " + new String(decryptedText));

	}

	/**
	 * This method encrypt or decrypt provided byteArray based on the provided encryptOrDecryptMode
	 * The original text or cipher text must be in byte array format
	 * @param key, Symmetric key to encrypt or decrypt text/cipher
	 * @param encryptOrDecryptMode, Cipher.ENCRYPT_MODE/Cipher.DECRYPT_MODE, what you want to do with the Cipher/text
	 * @param textOrCipher, original message / Cipher text
	 * @return byte[], byte[] of encrypted/decrypted text/cipher
	 */
	public static byte[] encryptOrDecryptText(Key key, int encryptOrDecryptMode, byte[] textOrCipher) throws NoSuchAlgorithmException
	, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(encryptOrDecryptMode, key);
		return cipher.doFinal(textOrCipher);
	}

	/**
	 * This method generate a symmetric key using the secretKey string  
	 * @param secretKey, original secret key in String format
	 * @param keyType, what type of key you want to generate(AES/DES/DES3/DSA)
	 * @return Key, A secret key object
	 */
	public static Key generateSymmetricKey(String secretKey, String keyType) {
		byte[] keyInByte = secretKey.getBytes();
		return new SecretKeySpec(keyInByte, keyType);
	}

}
