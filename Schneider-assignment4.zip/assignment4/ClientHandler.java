import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author mahmed27
 * 
 * Submission by Corey Schneider
 * ITIS 3200 - November 14, 2019
 */

class ClientHandler extends Thread {

	String line = null;
	BufferedReader inputStream = null;
	PrintWriter outputStream = null;
	Socket socket = null;

	public ClientHandler(Socket sock) {
		this.socket = sock;
	}

	public void run() {
		try {
			inputStream = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			outputStream = new PrintWriter(socket.getOutputStream());

		} catch(IOException e) {
			System.out.println("IO error in server thread");
		}

		try {
			line = inputStream.readLine();

			//outputStream.println("You are client "+this.getName()+" --- ID #"+this.getId());
			while(line.compareTo("QUIT") != 0) {
				// Generate a KeySS
				String key = "";
				try {
					key = Files.lines(Paths.get("./symmetricKey.txt")).findFirst().get();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				Key secretkey = generateSymmetricKey(key, "AES");

				byte[] decryptedText = null;
				try {
					decryptedText = encryptOrDecryptText(secretkey, Cipher.DECRYPT_MODE, DatatypeConverter.parseHexBinary(line)); //decrypt the encrypted binary
				} catch (Exception e) { e.printStackTrace(); }

				// Print the decrypted text
				//System.out.println("Decrypted message: "+new String(decryptedText));
				outputStream.println("Client-"+this.getId()+": [Decrypted]: "+new String(decryptedText));
				System.out.println("Client-"+this.getId()+": [Decrypted]: "+new String(decryptedText));
				outputStream.flush();
				line = inputStream.readLine();
			}   
		} catch (IOException e) {
			System.out.println("IO Error/ Client "+this.getName()+" terminated abruptly");
		} catch(NullPointerException e) {
			System.out.println("Client "+this.getName()+" closed");
		}

		finally {    
			try {
				System.out.println("Connection closing..");
				if (inputStream != null) {
					inputStream.close(); 
					System.out.println("Closed: Socket input stream");
				}

				if(outputStream != null) {
					outputStream.close();
					System.out.println("Closed: Socket output stream");
				}
				if (socket != null) {
					socket.close();
					System.out.println("Closed: Socket");
				}

			} catch(IOException ie) {
				System.out.println("Socket close error");
			}
		}
	}

	public static byte[] encryptOrDecryptText(Key key, int encryptOrDecryptMode, byte[] textOrCipher) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(encryptOrDecryptMode, key);
		return cipher.doFinal(textOrCipher);
	}

	public static Key generateSymmetricKey(String secretKey, String keyType) {
		byte[] keyInByte = secretKey.getBytes();
		return new SecretKeySpec(keyInByte, keyType);
	}

}

