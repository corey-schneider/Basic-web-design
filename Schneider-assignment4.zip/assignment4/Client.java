import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import javax.xml.bind.DatatypeConverter;

/**
 *
 * @author mahmed27
 * 
 * Submission by Corey Schneider
 * ITIS 3200 - November 14, 2019
 */

class Client {

	/**
	 * byte[] ciper = encrypt(blah)
	 * Reader.write(string)
	 * new String(cipher)
	 * DataTypeConverter.printHexBinary(byte[])
	 * DataTypeConverter.ParseHexBinary(string)
	 * 
	 * before you send and after you receive
	 */

	public static void main(String[] args) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, 
	InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

		String serverHostname = new String("127.0.0.1");
		int serverPort = 10007;
		String symmetricKeyDir = "./symmetricKey.txt";
		boolean debug = false;

		if (args.length == 3) {
			//pass the hostname through cmd argument
			serverHostname = args[0];
			serverPort = Integer.parseInt(args[1]);
			symmetricKeyDir = args[2];
		}
		System.out.println ("Attemping to connect to host " + serverHostname + " on port "+serverPort+".");

		Socket echoSocket = null;
		PrintWriter out = null;
		BufferedReader in = null;

		try {
			//Connect to server and open IO stream
			echoSocket = new Socket(serverHostname, serverPort);
			out = new PrintWriter(echoSocket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(echoSocket.getInputStream()));
		} catch (UnknownHostException e) {
			System.err.println("Don't know about host: " + serverHostname);
			System.exit(1);
		} catch (IOException e) {
			System.err.println("Couldn't get I/O for " + "the connection to: " + serverHostname);
			System.exit(1);
		}

		BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
		String userInput;
		System.out.println("You are connected");

		System.out.print("Message to send: ");
		while ((userInput = stdIn.readLine()) != null) {
			try {
				
				String key = "";
				try {
					key = Files.lines(Paths.get(symmetricKeyDir)).findFirst().get(); //get first value of this text file
				} catch (IOException e) { e.printStackTrace(); }

				// Generate a KeySS
				Key secretkey = generateSymmetricKey(key, "AES");

				// Encryt text using generated key
				byte[] encryptedText = encryptOrDecryptText(secretkey, Cipher.ENCRYPT_MODE, userInput.getBytes());

				if(debug) {
					System.out.println("Symmetric key Length: " + (key.getBytes().length * 8) + " bit. Key: "+key);
					String encryptedTextString = new String(encryptedText);
					System.out.println("CipherText/Encrypted message string: " + encryptedTextString);
				}

				out.println(DatatypeConverter.printHexBinary(encryptedText)); //send the encrypted message as binary

				//read reply from server
				String replyFromServer = in.readLine();
				if(replyFromServer.trim().toLowerCase().equals("bye")) {
					break;
				}
				System.out.println("Ans: " + replyFromServer);
				if(userInput.equalsIgnoreCase("get-ip 0")) {
					System.exit(0);
				}
				System.out.print("Message to send: ");
			} catch(SocketException e) {
				System.out.println("Closed connection");
			}
		}

		out.close();
		in.close();
		stdIn.close();
		echoSocket.close();
	}

	/**
	 * This method encrypt or decrypt provided byteArray based on the provided encryptOrDecryptMode
	 * The original text or cipher text must be in byte array format
	 * @param key, Symmetric key to encrypt or decrypt text/cipher
	 * @param encryptOrDecryptMode, Cipher.ENCRYPT_MODE/Cipher.DECRYPT_MODE, what you want to do with the Cipher/text
	 * @param textOrCipher, original message / Cipher text
	 * @return byte[], byte[] of encrypted/decrypted text/cipher
	 */
	public static byte[] encryptOrDecryptText(Key key, int encryptOrDecryptMode, byte[] textOrCipher) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		Cipher cipher = Cipher.getInstance(key.getAlgorithm());
		cipher.init(encryptOrDecryptMode, key);
		return cipher.doFinal(textOrCipher);
	}

	/**
	 * This method generate a symmetric key using the secretKey string  
	 * @param secretKey, original secret key in String format
	 * @param keyType, what type of key you want to generate(AES/DES/DES3/DSA)
	 * @return Key, A secret key object
	 */
	public static Key generateSymmetricKey(String secretKey, String keyType) {
		byte[] keyInByte = secretKey.getBytes();
		return new SecretKeySpec(keyInByte, keyType);
	}


}
