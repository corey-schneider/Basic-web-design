import java.net.*;
import java.io.*;

/**
 *
 * @author mahmed27
 * 
 * Submission by Corey Schneider
 * ITIS 3200 - November 14, 2019
 */

class Server {
	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = null;
		int port = 10007;

		if (args.length > 0) {
			port = Integer.parseInt(args[0]);
		}

		try {
			serverSocket = new ServerSocket(port);
			System.out.println("Listening on on port: "+port+".");
		} catch (IOException e) {
			System.err.println("Could not listen on port: "+port+".");
			System.exit(1);
		}

		Socket clientSocket = null;
		System.out.println ("Waiting for connection ...");
		while(true) {
			try {
				clientSocket = serverSocket.accept();
				ClientHandler st = new ClientHandler(clientSocket);
				st.start();
				System.out.println ("Connection successful.");
				System.out.println ("Waiting for input ...");
			} catch (IOException e) {
				System.err.println("Accept failed.");
				System.exit(1);
				serverSocket.close();
			}
		}
	}

}
