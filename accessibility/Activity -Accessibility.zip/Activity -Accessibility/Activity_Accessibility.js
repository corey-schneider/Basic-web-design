function openDialog() {
  document.getElementById("dialog").open = true;
}
function closeDialog() {
  document.getElementById("dialog").open = false;
}

